package com.demo.bigbear;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigbearApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigbearApplication.class, args);
	}

}
